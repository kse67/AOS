/*A) Write a C program to display the given message ‘n’ times. (make a use of setjmp and longjmp system
call) */
#include "stdio.h"
#include "stdlib.h"
#include "setjmp.h"
#include "string.h"
int main()
{
char m[50];
int n,c=0;
jmp_buf buf;
printf("\n enter message to display=>");
gets(m);
printf("\n enter n no of times=>");
scanf("%d",&n);
setjmp(buf);
printf("%s\n",m);
c++;
if(c<n)
longjmp(buf,1);
return 0;
}
