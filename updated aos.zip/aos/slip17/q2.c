/* B) Write a C program to display all the files from current directory which are created in a
particular month. */

#include<stdio.h>
#include<dirent.h>
#include<unistd.h>
#include<sys/stat.h>
#include<time.h>

int main()
{
  DIR *d;
  char *a;
  int num;
  printf("enter the month");
  scanf("%d",&num);
  struct dirent *dir;
  struct stat stats;
  d=opendir(".");
  if(d)
   {
      while((dir=readdir(d))!=NULL)
        {
           a=dir->d_name;
           printf("%s",a);
           if(stat(a,&stats)==0)
              {
                 printfFileProperties(stats,num);
              }
        }
   closedir(d);
  }
return(0);
}
void printfFileProperties(struct stat stats,int num)
 {   
     struct tm dt;
     dt=*(gmtime(&stats.st_ctime));
     if(dt.tm_mon==num)
       {
           printf("\n Created on-%d-%d-%d %d:%d:%d\n",dt.tm_mday,dt.tm_mon,dt.tm_year+1900,dt.tm_hour,dt.tm_min,dt.tm_sec );
       }
    
}
