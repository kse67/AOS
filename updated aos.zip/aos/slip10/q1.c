/* Write a C program to display statistics related to memory allocation system. (Use mallinfo() system call)

*/


#include "stdio.h"
#include "stdlib.h"
#include "malloc.h"
int main()
{
char *c;
struct mallinfo m;
m=mallinfo();
printf("\n Non_mapped space allocated=>%d",m.arena);
printf("\n number of free chunks=>%d",m.ordblks);
printf("\n Number of free fastbin bloks=>%d",m.smblks);
printf("\n Number of mmapped regions=>%d",m.hblks);
printf("\n space allocated in mmapped regions=>%d",m.hblkhd);
printf("\n See below=>%d",m.usmblks);
printf("\n Space in freed fastbin bloacks=>%d",m.fsmblks);
printf("\n Total allocated space=>%d",m.fordblks);
printf("\n Total free space=>%d",m.fordblks);
printf("\n Top-most,relesable space=>%d",m.keepcost);
return 0;
}
