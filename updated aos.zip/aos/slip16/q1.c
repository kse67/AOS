//Q1 a}
	
//Write a C program that catches the ctrl-c (SIGINT) signal for the first time and display the appropriate message and exits on pressing ctrl-c again.
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "signal.h"
void sh(int sig)
{
printf("\n SIGINT signal cought");
signal(SIGINT,SIG_DFL);
fflush(stdout);
}
int main()
{
signal(SIGINT,sh);
while(1)
{
}
return 0;
}


