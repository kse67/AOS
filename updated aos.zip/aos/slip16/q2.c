/*B) Write a C program to implement the following unix/linux command on current directory
ls –l > output.txt
DO NOT simply exec ls -l > output.txt or system command from the program.
*/

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
int main()
{
int pid;
pid=fork();
if(pid<0)
{
printf("fork failed\n");
exit(-1);
}
else if(pid==0)
{
execlp("/bin/ls","ls","-l",NULL);
}
else
{
wait(NULL);
printf("child completed\n");
exit(0);
}
}
