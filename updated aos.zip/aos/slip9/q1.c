/*Write a C program to display as well as resets the environment variable such as path, home, root etc.

*/

#include "stdio.h"
#include "stdlib.h"
#include "dirent.h"
#include "fcntl.h"
int main (int argc,char *argv[],char *env[])
{
int i;
printf("Envirmental Variable with values => \n");
for(i=0;env[i]!=NULL;i++)
printf("\n %s",env[i]);
printf("\n Reseting value of home,Root,Path =>\n");
setenv("HOME","BGS",1);
setenv("ROOT","xyz",1);
setenv("PATH","lmn",1);
printf("\n Envirmental variable after reset =>\n");
printf("\n Root=> %s",getenv("ROOT"));
printf("\n Path=> %s",getenv("PATH"));
printf("\n Home=> %s",getenv("HOME"));
return 0;
}
