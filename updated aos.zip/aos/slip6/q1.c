/*
Write a C program to map a given file in memory and display the contain of mapped file in reverse.
*/



#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "sys/stat.h"
#include "sys/types.h"
#include "sys/mman.h"
int main(int argc,char* argv[])
{
int fd,size,i;
struct stat s1;
char *f,ch;
if(argc<2)
{
printf("\n Enter file name on command line");
exit(0);
}
fd=open(argv[1],O_RDONLY);
if(fd<0)
{
printf("\n unable to open file");
exit(0);
}
stat(argv[1],&s1);
size=s1.st_size;
f=(char*)mmap(0,size,PROT_READ,MAP_PRIVATE,fd,0);
for(i=size-1;i>=0;i--)
{
ch=f[i];
printf("%c",ch);
}
return 0;
}
