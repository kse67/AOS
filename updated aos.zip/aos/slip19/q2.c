/*Write a C program which creates a child process to run linux/ unix command or any user defined program. The parent process set the signal handler for death of child signal and Alarm
signal. If a child process does not complete its execution in 5 second then parent process kills child process.
*/

#include<stdio.h>
#include<signal.h>
#include<stdlib.h>
void sighup();
void sigint();
void sigquit();
main()
{
int pid,i,j,k;
if ((pid = fork() ) < 0)
{
perror("fork");
exit(1);
}
if ( pid == 0)
{
signal(SIGHUP,sighup);
signal(SIGINT,sigint);
signal(SIGQUIT,sigquit);
for(;;);
}
else
{
j=0;
for(i=1;i<=5;i++)
{
j++;
printf("PARENT: sending SIGHUP Signal :%d\n",j);
kill(pid,SIGHUP);
sleep(3);
printf("PARENT: sending signal :%d\n",j);
kill (pid,SIGINT);
sleep(3);
}
sleep(3);
printf("Parent sending SIGQUIT\n");
kill(pid,SIGQUIT);
}
}
void sighup()
{
signal(SIGHUP,sighup);
printf("Child: I have received sighup\n");
}
void sigint()
{signal(SIGINT,sigint);
printf("Child: I have received sighINT\n");
}
void sigquit()
{
printf("My daddy has killed me\n");
exit(0);
}
